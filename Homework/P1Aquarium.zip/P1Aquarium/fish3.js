/**
 * Adit Garg, 02/18/19
 * fish1 class - creates a type of fish (child)
 */
"use strict";

class fish3 extends Fish {
    constructor() {
        super();
    }
	display(y) {
       super.display(y,2);
	}

   
}
