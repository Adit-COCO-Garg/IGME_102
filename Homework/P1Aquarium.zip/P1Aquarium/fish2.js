/**
 * Adit Garg, 02/18/19
 * fish2 class - creates a type of fish (child)
 */
"use strict";

class fish2 extends Fish {
    constructor() {
        super();
    }
	display(y) {
       super.display(y,1);
		
	}

    
}
