/*

 */
class tract_loc {
	constructor(tID, x, y, popul, mp, fp, monies, povM, povF) {
		this.id = tID;
		this.lat = x;
		this.long = y;
		this.population = popul;
		this.mPop = mp;
		this.fPop = fp;
		this.medIncome = monies;
		this.povertyM = povM;
		this.povertyF = povF;
	}


}
